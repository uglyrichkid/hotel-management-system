package com.example.demo.entity.booking;

public enum BookingPaymentStatus {
    NEW,
    PARTIALLY_PAID,
    PAID
}