package com.example.demo.entity.booking;

public enum BookingStatus {
    CREATED,
    CONFIRMED,
    CHECKED_IN,
    CHECKED_OUT,
    CANCELLED
}
